package org.ippul.infinispan.example.custom;

import java.io.IOException;
import java.math.BigDecimal;

import org.infinispan.protostream.MessageMarshaller;

public class BigDecimalMarshaller implements MessageMarshaller<BigDecimal> {

    @Override
    public Class<? extends BigDecimal> getJavaClass() {
        return BigDecimal.class;
    }

    @Override
    public String getTypeName() {
        return "java.math.BigDecimal";
    }

    @Override
    public BigDecimal readFrom(ProtoStreamReader reader) throws IOException {
        BigDecimal res = new BigDecimal(reader.readString("value"));
        return res;
    }

    @Override
    public void writeTo(ProtoStreamWriter writer, BigDecimal t) throws IOException {
        if(t!=null){
            writer.writeString("value", t.toPlainString());
        }
    }
 }
package org.ippul.infinispan.example.custom;

import java.io.UncheckedIOException;

import org.infinispan.protostream.SerializationContext;
import org.infinispan.protostream.SerializationContextInitializer;

public class BigDecimalInitializer implements SerializationContextInitializer {

    @Override
    public String getProtoFileName() {
       return "BigDeciamal.proto";
    }

    @Override
    public String getProtoFile() throws UncheckedIOException {
       return "package java.math;\n" +
        "/* @Indexed */\n" +
        "message BigDecimal {\n" +
        "    /* @Field */\n" +
        "       optional string value = 1;\n" +
        "};\n";
    }

    @Override
    public void registerSchema(SerializationContext serCtx) {
       serCtx.registerProtoFiles(org.infinispan.protostream.FileDescriptorSource.fromString(getProtoFileName(), getProtoFile()));
    }

    @Override
    public void registerMarshallers(SerializationContext serCtx) {
       serCtx.registerMarshaller(new BigDecimalMarshaller());
    }

 }